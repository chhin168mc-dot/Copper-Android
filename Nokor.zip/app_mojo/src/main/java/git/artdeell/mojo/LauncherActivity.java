package git.artdeell.mojo;

import git.artdeell.mojo.utils.AnimationManager;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import static android.content.res.Configuration.ORIENTATION_LANDSCAPE;
import static android.content.res.Configuration.ORIENTATION_PORTRAIT;
import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import androidx.preference.PreferenceManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.graphics.Color;
import android.os.Bundle;
import android.system.Os;
import android.os.Looper;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.ColorUtils;
import androidx.fragment.app.DialogFragment;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;

import com.kdt.mcgui.LauncherWallpaperView;
import com.kdt.mcgui.ProgressLayout;

import git.artdeell.mojo.space.IntroAnimator;
import git.artdeell.mojo.space.SpaceBackgroundView;

import git.artdeell.mojo.authenticator.accounts.Accounts;
import git.artdeell.mojo.extra.ExtraConstants;
import git.artdeell.mojo.extra.ExtraCore;
import git.artdeell.mojo.extra.ExtraListener;
import git.artdeell.mojo.fragments.MainMenuFragment;
import git.artdeell.mojo.fragments.RightPaneHomeFragment;
import git.artdeell.mojo.fragments.MicrosoftLoginFragment;
import git.artdeell.mojo.fragments.SelectAuthFragment;
import git.artdeell.mojo.fragments.SettingsHostFragment;
import git.artdeell.mojo.instances.Instance;
import git.artdeell.mojo.instances.InstanceInstaller;
import git.artdeell.mojo.instances.InstanceShortcut;
import git.artdeell.mojo.instances.Instances;
import git.artdeell.mojo.utils.lifecycle.ContextAwareDoneListener;
import git.artdeell.mojo.utils.lifecycle.ContextExecutor;
import git.artdeell.mojo.modding.modpacks.imagecache.IconCacheJanitor;
import git.artdeell.mojo.prefs.LauncherPreferences;
import git.artdeell.mojo.prefs.screens.LauncherPreferenceFragment;
import git.artdeell.mojo.progresskeeper.ProgressKeeper;
import git.artdeell.mojo.progresskeeper.TaskCountListener;
import git.artdeell.mojo.services.ProgressServiceKeeper;
import git.artdeell.mojo.tasks.mojson.MoJsonExtras;
import git.artdeell.mojo.tasks.AsyncVersionList;
import git.artdeell.mojo.tasks.mojson.MoJsonDownloader;
import git.artdeell.mojo.utils.LauncherBackground;
import git.artdeell.mojo.utils.NotificationUtils;
import git.artdeell.mojo.utils.ThemeColors;

public class LauncherActivity extends BaseActivity {
    public static final String SETTING_FRAGMENT_TAG = "SETTINGS_FRAGMENT";

    private static final long SHORTCUT_LAUNCH_DELAY_MS = 500L;
    private FragmentContainerView mFragmentView;
    private ImageButton mSettingsButton;
    private LauncherWallpaperView mWallpaper;
    private SpaceBackgroundView mSpace;
    private ProgressLayout mProgressLayout;
    private ProgressServiceKeeper mProgressServiceKeeper;
    private NotificationManager mNotificationManager;
    private static ActivityResultLauncher<String> mRequestPermissionLauncher;

    /* Allows to switch from one button "type" to another */
    private final FragmentManager.FragmentLifecycleCallbacks mFragmentCallbackListener = new FragmentManager.FragmentLifecycleCallbacks() {
        @Override
        public void onFragmentResumed(@NonNull FragmentManager fm, @NonNull Fragment f) {
            // Also called for the screens of the right pane of the main menu
            updateSettingsButton();
        }

        @Override
        public void onFragmentViewCreated(@NonNull FragmentManager fm, @NonNull Fragment f,
                                          @NonNull View v, @Nullable Bundle savedInstanceState) {
            // The screens that fill the launcher (settings, accounts, ...) show the wallpaper, blurred,
            // unless that is turned off. The main menu handles the screens of its own pane.
            if(isFullScreenScreen(fm, f)) applyScreenBackground(v);
        }
    };

    /* Listener for the back button in settings */
    private final ExtraListener<String> mBackPreferenceListener = (key, value) -> {
        if(value.equals("true")) onBackPressed();
        return false;
    };

    /* Listener for the auth method selection screen */
    private final ExtraListener<Boolean> mSelectAuthMethod = (key, value) -> {
        // The "false" value is used to stop auth method selection
        FragmentManager manager = getSupportFragmentManager();
        if(!value || manager.isStateSaved()) return false;
        Fragment fragment = manager.findFragmentById(mFragmentView.getId());
        // Allow starting the add account only from the main menu, should it be moved to fragment itself ?
        if(!(fragment instanceof MainMenuFragment)) return false;

        Tools.swapFragment(this, SelectAuthFragment.class, SelectAuthFragment.TAG, null);
        return false;
    };

    /* Listener for the settings fragment */
    private final View.OnClickListener mSettingButtonListener = v -> {
        FragmentManager manager = getSupportFragmentManager();
        if(manager.isStateSaved()) return;
        Fragment fragment = manager.findFragmentById(mFragmentView.getId());
        if(fragment instanceof MainMenuFragment){
            MainMenuFragment mainMenu = (MainMenuFragment) fragment;
            if(mainMenu.isRightPaneActive()) {
                // Home button of the two-pane main menu: close the screen in the right pane
                mainMenu.clearRightPane();
                return;
            }
            // The settings replace the whole screen, they are not opened in the right pane.
            // In landscape they have two panes of their own
            Class<? extends Fragment> settingsClass = getResources().getConfiguration().orientation == ORIENTATION_LANDSCAPE
                    ? SettingsHostFragment.class : LauncherPreferenceFragment.class;
            Tools.swapFragmentFullScreen(this, settingsClass, SETTING_FRAGMENT_TAG, null);
        } else{
            // The setting button doubles as a home button now
            Tools.backToMainMenu(this);
        }
    };

    private final ExtraListener<Boolean> mLaunchGameListener = (key, value) -> {
        if(!ProgressLayout.ensureNoOngoingTasks(this)) return false;

        Instance selectedInstance = Instances.loadSelectedInstance();

        if(selectedInstance == null) {
            Toast.makeText(this, R.string.no_instance, Toast.LENGTH_LONG).show();
            return false;
        }

        if(selectedInstance.installer != null) {
            selectedInstance.installer.start();
            return false;
        }

        if (!Tools.isValidString(selectedInstance.versionId)){
            Toast.makeText(this, R.string.error_no_version, Toast.LENGTH_LONG).show();
            return false;
        }

        if(Accounts.getCurrent() == null){
            Toast.makeText(this, R.string.no_saved_accounts, Toast.LENGTH_LONG).show();
            ExtraCore.setValue(ExtraConstants.SELECT_AUTH_METHOD, true);
            return false;
        }
        String normalizedVersionId = MoJsonExtras.normalizeVersionId(selectedInstance.versionId);
        JVersionList.Version mcVersion = MoJsonExtras.getListedVersion(normalizedVersionId);
        new MoJsonDownloader().start(
                this.getAssets(),
                mcVersion,
                normalizedVersionId,
                new ContextAwareDoneListener(this, normalizedVersionId)
        );
        return false;
    };

    private final TaskCountListener mDoubleLaunchPreventionListener = taskCount -> {
        // Hide the notification that starts the game if there are tasks executing.
        // Prevents the user from trying to launch the game with tasks ongoing.
        if(taskCount > 0) {
            Tools.runOnUiThread(() ->
                    mNotificationManager.cancel(NotificationUtils.NOTIFICATION_ID_GAME_START)
            );
        }
        return false;
    };
    /** The button is the settings button on the home screen, and the home button everywhere else */
    private void updateSettingsButton() {
        if(mSettingsButton == null) return;
        Fragment current = getSupportFragmentManager().findFragmentById(R.id.container_fragment);
        boolean atHome = current instanceof MainMenuFragment && !((MainMenuFragment) current).isRightPaneActive();
        mSettingsButton.setImageDrawable(ContextCompat.getDrawable(this,
                atHome ? R.drawable.ic_px_sliders : R.drawable.ic_px_home));
        // The wallpaper is behind every screen
        if(mWallpaper != null) mWallpaper.setActive(true);
        refreshWallpaperFocus();
    }

    private boolean isFullScreenScreen(@NonNull FragmentManager fm, @NonNull Fragment f) {
        // The callbacks also report the screens inside the main menu, the home of its right pane
        // must never get the cover of the other screens
        return fm == getSupportFragmentManager() && !(f instanceof MainMenuFragment)
                && !(f instanceof RightPaneHomeFragment) && !(f instanceof DialogFragment);
    }

    /** Remembers what a screen had as its background, to give it back when it isn't see-through anymore */
    private static final class OriginalBackground {
        final Drawable drawable;

        OriginalBackground(Drawable drawable) {
            this.drawable = drawable;
        }
    }

    /**
     * Makes the screen see-through, so the wallpaper behind it shows, or gives it its own background
     * back. It runs when the screen is created and again when Launcher appearance changes, so the
     * screen that is open follows the settings at once.
     */
    private void applyScreenBackground(@NonNull View v) {
        Object saved = v.getTag(R.id.launcher_screen_original_bg);
        if(!(saved instanceof OriginalBackground)) {
            saved = new OriginalBackground(v.getBackground());
            v.setTag(R.id.launcher_screen_original_bg, saved);
        }
        boolean seeThrough = LauncherBackground.isFullscreenActive(this) && LauncherBackground.showOnOtherScreens(this);
        if(!seeThrough) {
            // A screen that isn't see-through is always solid, whatever it had before
            Drawable original = ((OriginalBackground) saved).drawable;
            v.setBackground(original != null ? original : new ColorDrawable(ThemeColors.surface(this)));
            return;
        }
        // No cover unless Launcher appearance asks for one
        int overlay = LauncherBackground.getOverlay(this);
        v.setBackgroundColor(overlay == 0 ? Color.TRANSPARENT
                : ColorUtils.setAlphaComponent(ThemeColors.surface(this), Math.round(overlay * 2.55f)));
    }

    /** Applies the wallpaper settings to the screen that fills the launcher right now, if there is one */
    private void refreshScreenBackground() {
        Fragment current = getSupportFragmentManager().findFragmentById(R.id.container_fragment);
        if(current != null && current.getView() != null && isFullScreenScreen(getSupportFragmentManager(), current)) {
            applyScreenBackground(current.getView());
        }
    }

    private final SharedPreferences.OnSharedPreferenceChangeListener mBackgroundPrefListener = (prefs, key) -> {
        if(LauncherBackground.PREF_FULLSCREEN.equals(key) || LauncherBackground.PREF_OTHER_SCREENS.equals(key)
                || LauncherBackground.PREF_OVERLAY.equals(key) || LauncherBackground.PREF_KIND.equals(key)) {
            refreshScreenBackground();
        }
    };

    /** The wallpaper is sharp (as sharp as the blur setting says) behind the home screen only, every other screen blurs it */
    public void refreshWallpaperFocus() {
        if(mWallpaper == null) return;
        applyWallpaperFocus();
        // Fragment callbacks can run before the back stack and the panes have settled, so the
        // check is repeated once they have. Otherwise the wallpaper can stay blurred on the home screen.
        mWallpaper.post(this::applyWallpaperFocus);
    }

    private void applyWallpaperFocus() {
        if(mWallpaper == null) return;
        Fragment current = getSupportFragmentManager().findFragmentById(R.id.container_fragment);
        boolean atHome = current instanceof MainMenuFragment && !((MainMenuFragment) current).isRightPaneActive();
        mWallpaper.setFocused(atHome);
        // The space only moves where it can be seen
        if(mSpace != null) mSpace.setActive(atHome);
    }

    private final FragmentManager.OnBackStackChangedListener mWallpaperFocusListener = this::refreshWallpaperFocus;

    @Override
    protected boolean shouldIgnoreNotch() {
        return true;
    }

    @Override
    public boolean setFullscreen() {
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        boolean launchFromShortcut = savedInstanceState == null && selectShortcutInstance(getIntent());
        setContentView(R.layout.activity_mojo_ui);
        MoJsonDownloader.prepareSubstitutionMap(getAssets());
        // Reads the files of the runtime into the system cache while the player picks an instance
        git.artdeell.mojo.multirt.RuntimeManager.warmUpLikely(this);

        try {
            Os.setenv("TMPDIR", Tools.DIR_CACHE.getAbsolutePath(), true);
         }
        catch (Exception e) {
            throw new RuntimeException(e);
        }

        IconCacheJanitor.runJanitor();
        warmUpWebView();
        git.artdeell.mojo.update.UpdateManager.checkOnStartup(this);

        // Not null: with no background nothing clears the pixels behind a see-through screen or a hidden
        // wallpaper, and the old ones show through and smear. A solid color costs next to nothing.
        getWindow().setBackgroundDrawable(new ColorDrawable(ThemeColors.surface(this)));
        bindViews();
        // The opening animation plays when the app starts, not again after a rotation or a theme change
        View introSpace = findViewById(R.id.intro_space);
        View introOverlay = findViewById(R.id.intro_overlay);
        View introLogo = findViewById(R.id.intro_logo);
        View introTitle = findViewById(R.id.intro_title);
        if(savedInstanceState == null && introSpace instanceof SpaceBackgroundView
                && introOverlay != null && introLogo != null && introTitle != null) {
            IntroAnimator.play(introOverlay, (SpaceBackgroundView) introSpace, introLogo, introTitle);
        }
        PreferenceManager.getDefaultSharedPreferences(this).registerOnSharedPreferenceChangeListener(mBackgroundPrefListener);
        mRequestPermissionLauncher = this.registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isAllowed -> {
                    if(!isAllowed) Tools.runOnUiThread(() -> Toast.makeText(this, R.string.notification_permission_toast, Toast.LENGTH_LONG).show());
                }
        );
        checkNotificationPermission();
        if(LauncherPreferences.PREF_MIGRATION_NOTICE)
            MojoApplication.sExecutorService.submit(this::checkPreviousInstalls);

        mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        ProgressKeeper.addTaskCountListener(mDoubleLaunchPreventionListener);
        ProgressKeeper.addTaskCountListener((mProgressServiceKeeper = new ProgressServiceKeeper(this)));

        mSettingsButton.setOnClickListener(mSettingButtonListener);
        ProgressKeeper.addTaskCountListener(mProgressLayout);
        ExtraCore.addExtraListener(ExtraConstants.BACK_PREFERENCE, mBackPreferenceListener);
        ExtraCore.addExtraListener(ExtraConstants.SELECT_AUTH_METHOD, mSelectAuthMethod);

        ExtraCore.addExtraListener(ExtraConstants.LAUNCH_GAME, mLaunchGameListener);

        new AsyncVersionList().getVersionList(versions -> ExtraCore.setValue(ExtraConstants.RELEASE_TABLE, versions));

        mProgressLayout.observe(ProgressLayout.DOWNLOAD_GAME);
        mProgressLayout.observe(ProgressLayout.UNPACK_RUNTIME);
        mProgressLayout.observe(ProgressLayout.INSTALL_MODPACK);
        mProgressLayout.observe(ProgressLayout.AUTHENTICATE);
        mProgressLayout.observe(ProgressLayout.DOWNLOAD_VERSION_LIST);
        mProgressLayout.observe(ProgressLayout.INSTANCE_INSTALL);
        mProgressLayout.observe(ProgressLayout.DATA_MIGRATION);

        if(launchFromShortcut) {
            mFragmentView.postDelayed(() -> ExtraCore.setValue(ExtraConstants.LAUNCH_GAME, true), SHORTCUT_LAUNCH_DELAY_MS);
        }
    }

    /**
     * Selects the instance requested by an instance shortcut intent.
     * @return true if an instance was selected and should be launched
     */
    private static boolean selectShortcutInstance(Intent intent) {
        if(intent == null || !InstanceShortcut.ACTION_LAUNCH_INSTANCE.equals(intent.getAction())) return false;
        Instance instance = Instances.loadInstance(intent.getStringExtra(InstanceShortcut.EXTRA_INSTANCE_KEY));
        if(instance == null) return false;
        Instances.setSelectedInstance(instance);
        return true;
    }

    /**
     * The first WebView of a process takes a while to start (the browser engine is loaded then), and
     * that wait was spent in front of the login page. It is paid for here, while the launcher is idle.
     */
    private void warmUpWebView() {
        Looper.myQueue().addIdleHandler(() -> {
            try {
                WebView warm = new WebView(getApplicationContext());
                CookieManager.getInstance();
                warm.destroy();
            } catch (Throwable e) {
                // No WebView on this device, the login screens report that themselves
            }
            return false;
        });
    }

    /** The system bars slide in when a popup or a dialog takes the focus, hide them when the launcher has it back */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(!hasFocus || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return;
        if(isInMultiWindowMode()) return;
        WindowInsetsController controller = getWindow().getInsetsController();
        if(controller != null) controller.hide(WindowInsets.Type.systemBars());
    }

    @Override
    protected void onResume() {
        super.onResume();
        ContextExecutor.setActivity(this);
        InstanceInstaller.postInstallCheck(this);
        updateSettingsButton();
    }

    @Override
    protected void onPause() {
        super.onPause();
        ContextExecutor.clearActivity();
        // Nothing has to play while the launcher isn't in front
        if(mWallpaper != null) mWallpaper.setActive(false);
    }

    @Override
    protected void onStart() {
        super.onStart();
        getSupportFragmentManager().unregisterFragmentLifecycleCallbacks(mFragmentCallbackListener);
        getSupportFragmentManager().registerFragmentLifecycleCallbacks(mFragmentCallbackListener, true);
        getSupportFragmentManager().removeOnBackStackChangedListener(mWallpaperFocusListener);
        getSupportFragmentManager().addOnBackStackChangedListener(mWallpaperFocusListener);
        // A screen that was restored (the theme changed, the screen rotated) made its views during
        // super.onStart(), before the callbacks above existed, so it has to be caught up with
        refreshScreenBackground();
        AnimationManager.installFragmentTransitions(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        PreferenceManager.getDefaultSharedPreferences(this).unregisterOnSharedPreferenceChangeListener(mBackgroundPrefListener);
        mProgressLayout.cleanUpObservers();
        ProgressKeeper.removeTaskCountListener(mProgressLayout);
        ProgressKeeper.removeTaskCountListener(mProgressServiceKeeper);
        ExtraCore.removeExtraListenerFromValue(ExtraConstants.BACK_PREFERENCE, mBackPreferenceListener);
        ExtraCore.removeExtraListenerFromValue(ExtraConstants.SELECT_AUTH_METHOD, mSelectAuthMethod);
        ExtraCore.removeExtraListenerFromValue(ExtraConstants.LAUNCH_GAME, mLaunchGameListener);

        getSupportFragmentManager().unregisterFragmentLifecycleCallbacks(mFragmentCallbackListener);
        getSupportFragmentManager().removeOnBackStackChangedListener(mWallpaperFocusListener);
    }

    /** Custom implementation to feel more natural when a backstack isn't present */
    @Override
    public void onBackPressed() {
        MicrosoftLoginFragment fragment = (MicrosoftLoginFragment) getVisibleFragment(MicrosoftLoginFragment.TAG);
        if(fragment != null){
            if(fragment.canGoBack()){
                fragment.goBack();
                return;
            }
        }

        super.onBackPressed();
    }

    @SuppressWarnings("SameParameterValue")
    private Fragment getVisibleFragment(String tag){
        Fragment fragment = findFragmentByTag(getSupportFragmentManager(), tag);
        if(fragment != null && fragment.isVisible()) {
            return fragment;
        }
        return null;
    }

    /** Looks in the fragments nested in others too, like the ones in the right pane of the main menu */
    private static Fragment findFragmentByTag(FragmentManager manager, String tag) {
        Fragment fragment = manager.findFragmentByTag(tag);
        if(fragment != null) return fragment;
        for(Fragment child : manager.getFragments()) {
            fragment = findFragmentByTag(child.getChildFragmentManager(), tag);
            if(fragment != null) return fragment;
        }
        return null;
    }

    @SuppressWarnings("unused")
    private Fragment getVisibleFragment(int id){
        Fragment fragment = getSupportFragmentManager().findFragmentById(id);
        if(fragment != null && fragment.isVisible()) {
            return fragment;
        }
        return null;
    }

    public void askForPermission(int minApi, final String permission) {
        if(Build.VERSION.SDK_INT < minApi) return;
        mRequestPermissionLauncher.launch(permission);
    }
    public boolean checkForPermission(int minApi, final String permission) {
        return Build.VERSION.SDK_INT < minApi ||
                ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_DENIED;
    }
    public boolean checkForPermissionRationale(int minApi, final String permission) {
        return checkForPermission(minApi, permission) || ActivityCompat.shouldShowRequestPermissionRationale(this, permission);
    }

    private void checkNotificationPermission() {
        if(LauncherPreferences.PREF_SKIP_NOTIFICATION_PERMISSION_CHECK ||
            this.checkForPermission(33, Manifest.permission.POST_NOTIFICATIONS)) {
            return;
        }
        showNotificationPermissionReasoning();
    }

    // Call async
    private void checkPreviousInstalls(){
        final String[] packages = {"git.artdeell.mojo", "git.artdeell.mojo.debug", "git.artdeell.mojo.pub"};
        for(String s : packages){
            Intent i = getPackageManager().getLaunchIntentForPackage(s);
            if(i == null) continue;
            Tools.runOnUiThread(() ->
                    new MaterialAlertDialogBuilder(this)
                        .setTitle(R.string.migration_progress_warning_title)
                        .setMessage(R.string.migration_notice)
                        .setPositiveButton(android.R.string.ok, (d, button) -> LauncherPreferences.DEFAULT_PREF.edit().putBoolean("migrationNotice", false).apply())
                        .setOnDismissListener(d -> LauncherPreferences.PREF_MIGRATION_NOTICE = false)
                        .show());
            break;
        }
    }

    private void showNotificationPermissionReasoning() {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.notification_permission_dialog_title)
                .setMessage(R.string.notification_permission_dialog_text)
                .setPositiveButton(android.R.string.ok, (d, w) ->
                        askForPermission(33, Manifest.permission.POST_NOTIFICATIONS))
                .setNegativeButton(android.R.string.cancel, (d, w)-> handleNoNotificationPermission())
                .show();
    }

    private void handleNoNotificationPermission() {
        LauncherPreferences.PREF_SKIP_NOTIFICATION_PERMISSION_CHECK = true;
        LauncherPreferences.DEFAULT_PREF.edit()
                .putBoolean(LauncherPreferences.PREF_KEY_SKIP_NOTIFICATION_CHECK, true)
                .apply();
    }

    /** Stuff all the view boilerplate here */
    private void bindViews(){
        mFragmentView = findViewById(R.id.container_fragment);
        mSettingsButton = findViewById(R.id.setting_button);
        mProgressLayout = findViewById(R.id.progress_layout);
        mWallpaper = findViewById(R.id.launcher_wallpaper);
        View space = findViewById(R.id.space_background);
        mSpace = space instanceof SpaceBackgroundView ? (SpaceBackgroundView) space : null;
        // The account bar lets the space show through
        View accountBar = findViewById(R.id.account_spinner);
        accountBar.setBackgroundColor(ColorUtils.setAlphaComponent(ThemeColors.surfaceContainer(this), 0xCC));
        // The menu and settings buttons are part of the same bar
        applyBarAlpha(findViewById(R.id.quick_menu_button));
        applyBarAlpha(mSettingsButton);
    }

    /** Gives the first layer of a bar button (see bg_topbar_button) the same transparency as the account bar */
    private static void applyBarAlpha(@Nullable View button) {
        if(button == null || button.getBackground() == null) return;
        Drawable background = button.getBackground().mutate();
        if(!(background instanceof RippleDrawable) || ((RippleDrawable) background).getNumberOfLayers() == 0) return;
        Drawable content = ((RippleDrawable) background).getDrawable(0);
        if(content instanceof LayerDrawable && ((LayerDrawable) content).getNumberOfLayers() > 0) {
            ((LayerDrawable) content).getDrawable(0).setAlpha(0xCC);
        }
    }
}
