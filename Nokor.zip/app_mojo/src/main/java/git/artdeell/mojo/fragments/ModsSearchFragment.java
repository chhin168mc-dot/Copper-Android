package git.artdeell.mojo.fragments;

import git.artdeell.mojo.instances.Instances;
import git.artdeell.mojo.instances.Instance;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.math.MathUtils;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kdt.mcgui.ProgressLayout;

import git.artdeell.mojo.MojoApplication;
import git.artdeell.mojo.R;
import git.artdeell.mojo.Tools;
import git.artdeell.mojo.modding.modpacks.ModItemAdapter;
import git.artdeell.mojo.modding.modpacks.api.CommonApi;
import git.artdeell.mojo.modding.modpacks.api.ModpackApi;
import git.artdeell.mojo.modding.modpacks.api.ModrinthApi;
import git.artdeell.mojo.modding.modpacks.models.ModDetail;
import git.artdeell.mojo.modding.modpacks.models.ModItem;
import git.artdeell.mojo.modding.modpacks.models.SearchFilters;
import git.artdeell.mojo.modding.modpacks.models.Constants;
import git.artdeell.mojo.modding.modpacks.models.ContentType;
import git.artdeell.mojo.prefs.LauncherPreferences;
import git.artdeell.mojo.progresskeeper.ProgressKeeper;
import git.artdeell.mojo.utils.profiles.VersionSelectorDialog;
import git.artdeell.mojo.utils.DownloadUtils;
import git.artdeell.mojo.utils.WorldUtils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Searches and installs individual mods into the current instance's mods folder.
 * - Version filter: when an MC version is selected, only versions matching it are shown.
 * - Dependency dialog: shown before download, matching the ModBundle UI.
 */
public class ModsSearchFragment extends Fragment implements ModItemAdapter.SearchResultCallback {

    public static final String TAG = "ModsSearchFragment";

    /** Bundle key: pre-seed the MC version filter (e.g. "1.20.1"). */
    public static final String ARG_PRESET_MC_VERSION = "preset_mc_version";
    /** Bundle key: pre-seed the mod loader filter ("fabric","forge","quilt","neoforge"). */
    public static final String ARG_PRESET_LOADER     = "preset_loader";
    /** Bundle key: which kind of content to browse. Value is a ContentType enum
     *  name(); defaults to MOD when absent. */
    public static final String ARG_CONTENT_TYPE      = "content_type";
    /** Bundle key: folder name of the world a datapack is installed into. Without it the world is
     *  asked for at every datapack install. */
    public static final String ARG_TARGET_WORLD      = "target_world";

    private View mOverlay;
    private float mOverlayTopCache;

    private final RecyclerView.OnScrollListener mOverlayPositionListener = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
            mOverlay.setY(MathUtils.clamp(mOverlay.getY() - dy, -mOverlay.getHeight(), mOverlayTopCache));
        }
    };

    private EditText mSearchEditText;
    private ImageButton mFilterButton;
    private RecyclerView mRecyclerview;
    private ModItemAdapter mModItemAdapter;
    private ProgressBar mSearchProgressBar;
    private TextView mStatusTextView;
    private ColorStateList mDefaultTextColor;

    private ModpackApi mModpackApi;
    private final SearchFilters mSearchFilters;

    public ModsSearchFragment() {
        super(R.layout.fragment_mod_search);
        mSearchFilters = new SearchFilters();
        mSearchFilters.isModpack = false;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        String curseforgeApiKey = LauncherPreferences.PREF_DISABLE_CURSEFORGE_API
                ? null : LauncherPreferences.resolveCurseforgeApiKey(context);
        mModpackApi = new ModsInstallApi(curseforgeApiKey, mSearchFilters);
        ((ModsInstallApi) mModpackApi).mActivityContext = context;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        mModItemAdapter = new ModItemAdapter(getResources(), mModpackApi, this);
        ProgressKeeper.addTaskCountListener(mModItemAdapter);
        mOverlayTopCache = getResources().getDimension(R.dimen.fragment_padding_medium);

        mOverlay           = view.findViewById(R.id.search_mod_overlay);
        mSearchEditText    = view.findViewById(R.id.search_mod_edittext);
        mSearchProgressBar = view.findViewById(R.id.search_mod_progressbar);
        mRecyclerview      = view.findViewById(R.id.search_mod_list);
        mStatusTextView    = view.findViewById(R.id.search_mod_status_text);
        mFilterButton      = view.findViewById(R.id.search_mod_filter);

        mDefaultTextColor = mStatusTextView.getTextColors();

        mRecyclerview.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerview.setAdapter(mModItemAdapter);
        mRecyclerview.addOnScrollListener(mOverlayPositionListener);

        mSearchEditText.setOnEditorActionListener((v, actionId, event) -> {
            searchMods(mSearchEditText.getText().toString());
            mSearchEditText.clearFocus();
            return false;
        });

        mOverlay.post(() -> {
            int overlayHeight = mOverlay.getHeight();
            mRecyclerview.setPadding(
                    mRecyclerview.getPaddingLeft(),
                    mRecyclerview.getPaddingTop() + overlayHeight,
                    mRecyclerview.getPaddingRight(),
                    mRecyclerview.getPaddingBottom());
        });

        mFilterButton.setOnClickListener(v -> displayFilterDialog());

        // Tapping a result opens its detail screens instead of expanding the card
        mModItemAdapter.setOnContentClickListener(item ->
                ContentDetailFragment.open(requireActivity(), item, mModpackApi, mSearchFilters.contentType));

        // Apply any pre-seeded filters passed in from the Manage Content picker
        applyPresetArgs();

        mSearchEditText.setHint(searchHintRes());

        if (mSearchFilters.contentType == ContentType.WORLD && LauncherPreferences.PREF_DISABLE_CURSEFORGE_API) {
            Toast.makeText(requireContext(), R.string.world_needs_curseforge, Toast.LENGTH_LONG).show();
        }

        searchMods(null);
    }

    private int searchHintRes() {
        switch (mSearchFilters.contentType) {
            case RESOURCE_PACK: return R.string.hint_search_resourcepack;
            case SHADER_PACK:   return R.string.hint_search_shaderpack;
            case WORLD:         return R.string.hint_search_world;
            case DATAPACK:      return R.string.hint_search_datapack;
            default:            return R.string.hint_search_mod;
        }
    }

    /**
     * Reads ARG_CONTENT_TYPE / ARG_PRESET_MC_VERSION / ARG_PRESET_LOADER from the
     * fragment's arguments and seeds mSearchFilters before the first search. This
     * lets ManageModsFragment (via the Manage Content picker) pass in the current
     * instance's content type + version/loader so the search opens already filtered.
     *
     * The loader preset is only applied for MOD — resource packs and shader packs
     * aren't loader-specific, so a saved loader filter is ignored for those, both
     * here and in the filter dialog itself.
     */
    private void applyPresetArgs() {
        Bundle args = getArguments();
        if (args == null) return;

        String contentTypeName = args.getString(ARG_CONTENT_TYPE, null);
        if (contentTypeName != null) {
            mSearchFilters.contentType = ContentType.valueOf(contentTypeName);
        }
        // Modrinth has no worlds, CurseForge is the only source for them
        if (!mSearchFilters.contentType.onModrinth()) mSearchFilters.engine = Constants.ENGINE_CURSEFORGE;
        String targetWorld = args.getString(ARG_TARGET_WORLD, null);
        if (targetWorld != null && !targetWorld.isEmpty() && mModpackApi instanceof ModsInstallApi) {
            ((ModsInstallApi) mModpackApi).mTargetWorld = targetWorld;
        }

        String presetVersion = args.getString(ARG_PRESET_MC_VERSION, null);
        String presetLoader  = args.getString(ARG_PRESET_LOADER,     null);

        if (presetVersion != null && !presetVersion.isEmpty()) {
            mSearchFilters.mcVersion = presetVersion;
        }
        if (mSearchFilters.contentType == ContentType.MOD
                && presetLoader != null && !presetLoader.isEmpty()) {
            mSearchFilters.modLoader = presetLoader;
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ProgressKeeper.removeTaskCountListener(mModItemAdapter);
        mRecyclerview.removeOnScrollListener(mOverlayPositionListener);
    }

    @Override
    public void onSearchFinished() {
        mSearchProgressBar.setVisibility(View.GONE);
        mStatusTextView.setVisibility(View.GONE);
    }

    @Override
    public void onSearchError(int error) {
        mSearchProgressBar.setVisibility(View.GONE);
        mStatusTextView.setVisibility(View.VISIBLE);
        switch (error) {
            case ERROR_INTERNAL:
                mStatusTextView.setTextColor(Color.RED);
                mStatusTextView.setText(R.string.search_mod_error);
                break;
            case ERROR_NO_RESULTS:
                mStatusTextView.setTextColor(mDefaultTextColor);
                mStatusTextView.setText(R.string.search_mod_no_result);
                break;
        }
    }

    private void searchMods(String name) {
        mSearchProgressBar.setVisibility(View.VISIBLE);
        mSearchFilters.name = name == null ? "" : name;
        mModItemAdapter.performSearchQuery(mSearchFilters);
    }

    /** Opens the filter dialog. The search bar button calls it in portrait, in landscape the filter
     *  button of ContentPickerFragment's left pane does (layout-land hides the search bar button). */
    public void displayFilterDialog() {
        boolean showLoaderFilter = supportsLoaderFilter();

        SearchFilterDialog.Options options = new SearchFilterDialog.Options();
        options.showLoader = showLoaderFilter;
        options.showEngine = mSearchFilters.contentType.onModrinth() && mSearchFilters.contentType.onCurseforge();
        options.engine = mSearchFilters.engine;
        options.mcVersion = mSearchFilters.mcVersion != null ? mSearchFilters.mcVersion : "";
        options.loader = mSearchFilters.modLoader != null ? mSearchFilters.modLoader : "";

        // Nothing picked yet: start from the version/loader the current instance runs
        if (options.mcVersion.isEmpty() && options.loader.isEmpty()) {
            String profileKey = Instances.getSelectedInstanceKey();
            if (!profileKey.isEmpty()) {
                InstanceVersionResolver.Info info = InstanceVersionResolver.resolve(profileKey);
                if (info.mcVersion != null) options.mcVersion = info.mcVersion;
                if (showLoaderFilter && !info.loader.isEmpty()) options.loader = info.loader;
            }
        }

        options.showCategories = true;
        options.category = mSearchFilters.category;
        options.categoryProvider = engine -> mModpackApi.getCategories(mSearchFilters.forCategories(engine));
        options.onCategoryApply = category -> mSearchFilters.category = category;

        SearchFilterDialog.show(requireContext(), options,
                (engine, version, loader) -> applyFilters(engine, version, loader));
    }

    // ── Filter access ─────────────────────────────────────────────────────────

    public int getEngine() { return mSearchFilters.engine; }

    @NonNull
    public String getMcVersion() { return mSearchFilters.mcVersion != null ? mSearchFilters.mcVersion : ""; }

    @NonNull
    public String getModLoader() { return mSearchFilters.modLoader != null ? mSearchFilters.modLoader : ""; }

    /** Resource packs and shader packs aren't loader specific, mods and datapacks are */
    public boolean supportsLoaderFilter() {
        return mSearchFilters.contentType == ContentType.MOD || mSearchFilters.contentType == ContentType.DATAPACK;
    }

    /** Sets the filters and searches again */
    public void applyFilters(int engine, @NonNull String mcVersion, @NonNull String loader) {
        if (mSearchFilters.contentType.onModrinth()) mSearchFilters.engine = engine;
        mSearchFilters.mcVersion = mcVersion;
        mSearchFilters.modLoader = supportsLoaderFilter() ? loader : "";
        if (mSearchEditText != null) searchMods(mSearchEditText.getText().toString());
    }

    // ── ModsInstallApi ────────────────────────────────────────────────────────

    static class ModsInstallApi extends CommonApi implements git.artdeell.mojo.modding.modpacks.api.InstalledStateResolver,
            git.artdeell.mojo.modding.modpacks.api.UnfilteredVersionsProvider {

        private final SearchFilters mFilters;
        private final ModrinthApi mModrinthApi = new ModrinthApi();
        private final Handler mMainHandler = new Handler(Looper.getMainLooper());
        private Context mActivityContext;
        /** World the datapacks go into when the browser was opened from a world's datapacks */
        @Nullable private String mTargetWorld;
        /** World picked for the datapack that is being installed right now */
        @Nullable private volatile String mPickedWorld;
        @Nullable
        private final git.artdeell.mojo.modding.modpacks.api.CurseforgeApi mCurseforgeApi;

        /** @param curseforgeApiKey null when CurseForge is disabled in experimental settings */
        ModsInstallApi(@Nullable String curseforgeApiKey, SearchFilters filters) {
            super(curseforgeApiKey != null ? curseforgeApiKey : "", curseforgeApiKey == null);
            mFilters = filters;
            mCurseforgeApi = curseforgeApiKey != null
                    ? new git.artdeell.mojo.modding.modpacks.api.CurseforgeApi(curseforgeApiKey)
                    : null;
        }

        /**
         * Override getModDetails to filter versions by the selected MC version.
         * Only versions matching the filter are shown in the version dropdown.
         * Also resolves which (if any) of the returned versions is already
         * installed in the current instance's mods folder, so the install
         * button can show Install / Installed / Update / Downgrade.
         */
        @Override
        public ModDetail getModDetails(ModItem item) {
            return loadDetails(item, true);
        }

        @Override
        public ModDetail getAllVersions(ModItem item) {
            return loadDetails(item, false);
        }

        private ModDetail loadDetails(ModItem item, boolean applyFilters) {
            ModDetail detail;
            String filterVer = applyFilters && mFilters.mcVersion != null && !mFilters.mcVersion.isEmpty()
                    ? mFilters.mcVersion : null;
            String filterLoader = applyFilters && mFilters.modLoader != null && !mFilters.modLoader.isEmpty()
                    ? mFilters.modLoader : null;
            if (item.apiSource == git.artdeell.mojo.modding.modpacks.models.Constants.SOURCE_MODRINTH) {
                detail = mModrinthApi.getModDetails(item, filterVer, filterLoader);
            } else if (item.apiSource == git.artdeell.mojo.modding.modpacks.models.Constants.SOURCE_CURSEFORGE) {
                if (mCurseforgeApi == null) return null; // disabled in experimental settings
                detail = mCurseforgeApi.getModDetails(item, filterVer, filterLoader);
            } else {
                detail = super.getModDetails(item);
            }

            if (detail != null && !detail.isModpack) {
                resolveInstalledVersionIndex(detail);
            }
            return detail;
        }

        @Override
        public void resolveInstalledState(ModDetail detail) {
            if (detail != null && !detail.isModpack) resolveInstalledVersionIndex(detail);
        }

        /**
         * Hashes every jar currently in the mods folder (enabled or disabled)
         * and matches against detail.versionHashes to find which version, if
         * any, is already installed. Sets detail.installedVersionIndex
         * accordingly (-1 if this mod isn't installed at all).
         */
        private void resolveInstalledVersionIndex(ModDetail detail) {
            detail.installedVersionIndex = -1;
            detail.installedFilePath = null;
            if (!mFilters.contentType.isGameFolderFiles()) return;
            if (detail.versionHashes == null || detail.versionHashes.length == 0) return;

            File modsDir = getModsDir();
            if (modsDir == null) return;
            File[] files = modsDir.listFiles(f -> f.isFile() &&
                    (f.getName().endsWith(mFilters.contentType.fileExtension) ||
                            f.getName().endsWith(mFilters.contentType.fileExtension + ".disabled")));
            if (files == null || files.length == 0) return;

            java.util.Map<String, File> installedHashToFile = new java.util.HashMap<>();
            for (File f : files) {
                String hash = sha1Hex(f);
                if (hash != null) installedHashToFile.put(hash, f);
            }
            if (installedHashToFile.isEmpty()) return;

            for (int i = 0; i < detail.versionHashes.length; i++) {
                String hash = detail.versionHashes[i];
                if (hash == null) continue;
                File match = installedHashToFile.get(hash.toLowerCase(java.util.Locale.ROOT));
                if (match != null) {
                    detail.installedVersionIndex = i;
                    detail.installedFilePath = match.getAbsolutePath();
                    break;
                }
            }
        }

        /* Hashing every jar for every version lookup was the slowest part of opening a mod. A jar's
         * hash only changes when the file does, so it is remembered by path, size and timestamp. */
        private static final java.util.concurrent.ConcurrentHashMap<String, String> sHashCache =
                new java.util.concurrent.ConcurrentHashMap<>();

        private static String sha1Hex(File file) {
            String key = file.getAbsolutePath() + "|" + file.length() + "|" + file.lastModified();
            String cached = sHashCache.get(key);
            if (cached != null) return cached;
            String hash = computeSha1Hex(file);
            if (hash != null) sHashCache.put(key, hash);
            return hash;
        }

        private static String computeSha1Hex(File file) {
            try {
                java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-1");
                byte[] buffer = new byte[8192];
                try (java.io.FileInputStream fis = new java.io.FileInputStream(file)) {
                    int read;
                    while ((read = fis.read(buffer)) != -1) digest.update(buffer, 0, read);
                }
                byte[] bytes = digest.digest();
                StringBuilder sb = new StringBuilder(bytes.length * 2);
                for (byte b : bytes) sb.append(String.format("%02x", b));
                return sb.toString();
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        public void handleInstallation(Context context, ModDetail modDetail, int selectedVersion) {
            if (modDetail.isModpack) {
                super.handleInstallation(context, modDetail, selectedVersion);
                return;
            }

            String url = modDetail.versionUrls[selectedVersion];

            // Check if this is a CF-restricted mod using the flag set during search
            boolean isCfRestricted = modDetail.apiSource == Constants.SOURCE_CURSEFORGE
                    && (modDetail.isRestricted || url == null || url.isEmpty());

            if (isCfRestricted) {
                String cfUrl = (modDetail.websiteUrl != null && !modDetail.websiteUrl.isEmpty())
                        ? modDetail.websiteUrl
                        : "https://www.curseforge.com/minecraft/mc-mods/" + modDetail.id;
                Context dialogCtx = mActivityContext != null ? mActivityContext : context;
                mMainHandler.post(() ->
                    new MaterialAlertDialogBuilder(dialogCtx)
                        .setTitle(modDetail.title)
                        .setMessage("This mod restricts third-party downloads.\n\nDownload it manually from CurseForge and place it in your mods folder:\n\n" + cfUrl)
                        .setPositiveButton("Open CurseForge", (d, w) ->
                            Tools.openURL((android.app.Activity) dialogCtx, cfUrl))
                        .setNegativeButton(android.R.string.cancel, null)
                        .show()
                );
                return;
            }

            if (url == null || url.isEmpty()) {
                Tools.showErrorRemote(context, R.string.modpack_install_download_failed,
                        new IOException("No download URL available for this mod"));
                return;
            }

            if (mFilters.contentType == ContentType.WORLD) {
                installWorld(context, url, modDetail.title);
                return;
            }

            if (mFilters.contentType == ContentType.DATAPACK && currentWorld() == null) {
                Context dialogCtx = mActivityContext != null ? mActivityContext : context;
                mMainHandler.post(() -> WorldUtils.pickWorld(dialogCtx, R.string.datapack_pick_world, world -> {
                    mPickedWorld = world;
                    handleInstallation(context, modDetail, selectedVersion);
                }));
                return;
            }

            // Extract filename
            String rawName = url.substring(url.lastIndexOf('/') + 1);
            if (rawName.contains("?")) rawName = rawName.substring(0, rawName.indexOf('?'));
            final String fileName = rawName.endsWith(mFilters.contentType.fileExtension) ? rawName : rawName + mFilters.contentType.fileExtension;

            // If a different version of this same mod is already installed under
            // a different file name (the Update/Downgrade case), remember its path
            // so downloadMod() can remove it once the new file is safely down —
            // otherwise both versions end up sitting in the mods folder together.
            final String oldFilePath = modDetail.installedFilePath;

            // Check if this version has dependencies
            ModDetail.Dependencies[] versionDeps = (modDetail.dependencies != null && selectedVersion < modDetail.dependencies.length)
                    ? modDetail.dependencies[selectedVersion] : null;
            String[] depIds   = null;
            String[] depTypes = null;
            if (versionDeps != null) {
                depIds   = new String[versionDeps.length];
                depTypes = new String[versionDeps.length];
                for (int i = 0; i < versionDeps.length; i++) {
                    depIds[i]   = versionDeps[i].project_id;
                    depTypes[i] = versionDeps[i].dependency_type;
                }
            }

            if (depIds == null || depIds.length == 0) {
                // No deps — download directly
                downloadMod(context, url, fileName, new String[0], new String[0], oldFilePath);
                return;
            }

            // Drop any dependency that's already sitting in the mods folder (as any
            // version, not just the one this mod happens to ask for) — otherwise every
            // reinstall/update of a mod with common dependencies (Fabric API, Cloth
            // Config, etc.) nags you to "install" something you already have.
            final String[] finalDepIds = depIds;
            final String[] finalDepTypes = depTypes;
            MojoApplication.sExecutorService.execute(() -> {
                java.util.Set<String> installedProjectIds = getInstalledModrinthProjectIds();
                List<String> remainingIds = new ArrayList<>();
                List<String> remainingTypes = new ArrayList<>();
                for (int i = 0; i < finalDepIds.length; i++) {
                    if (finalDepIds[i] != null && installedProjectIds.contains(finalDepIds[i])) continue;
                    remainingIds.add(finalDepIds[i]);
                    remainingTypes.add((finalDepTypes != null && i < finalDepTypes.length) ? finalDepTypes[i] : "required");
                }

                if (remainingIds.isEmpty()) {
                    // Every dependency is already installed — no need to prompt at all
                    mMainHandler.post(() ->
                            downloadMod(context, url, fileName, new String[0], new String[0], oldFilePath));
                    return;
                }

                mMainHandler.post(() -> promptForDependencies(context, url, fileName,
                        remainingIds.toArray(new String[0]), remainingTypes.toArray(new String[0]), oldFilePath));
            });
        }

        /** Fetches display names for the (already filtered to not-yet-installed) dependency
         *  list, then shows the install dialog once every name has resolved.
         *
         *  The filter that ran before this only drops dependencies whose exact jar hash
         *  matches something already in the mods folder on Modrinth's own database — so a
         *  dependency that's installed but came from CurseForge, or was placed manually,
         *  has a completely different file hash and slips right through, appearing in the
         *  dialog as "required"/"optional" even though it's already there. To catch that,
         *  we additionally read the mod id directly out of every installed jar's own
         *  metadata (fabric.mod.json / quilt.mod.json / mods.toml) — this is source-agnostic
         *  and needs no network — and cross-check it against each dependency's Modrinth slug. */
        private void promptForDependencies(Context context, String url, String fileName,
                                            String[] depIds, String[] depTypes, String oldFilePath) {
            final java.util.Set<String> installedModIds = getInstalledModIds();

            String[] labels = new String[depIds.length];
            String[] slugs = new String[depIds.length];
            final boolean[] checkedDefaults = new boolean[depIds.length];
            AtomicInteger remaining = new AtomicInteger(depIds.length);

            for (int i = 0; i < depIds.length; i++) {
                final int idx = i;
                final String type = (depTypes != null && idx < depTypes.length) ? depTypes[idx] : "required";
                final String prefix;
                switch (type) {
                    case "required":      prefix = "Required: ";     break;
                    case "incompatible":  prefix = "Incompatible: "; break;
                    case "embedded":      prefix = "Embedded: ";     break;
                    default:              prefix = "Optional: ";     break;
                }
                checkedDefaults[idx] = "required".equals(type);

                final String projectId = depIds[idx];
                MojoApplication.sExecutorService.execute(() -> {
                    // Fetch project title + slug from Modrinth
                    String[] details = fetchProjectDetails(projectId);
                    String name = details != null ? details[0] : null;
                    slugs[idx] = details != null ? details[1] : null;
                    labels[idx] = prefix + (name != null ? name : projectId);
                    if (remaining.decrementAndGet() == 0) {
                        mMainHandler.post(() -> finishDependencyPrompt(context, url, fileName,
                                depIds, depTypes, labels, slugs, checkedDefaults, installedModIds, oldFilePath));
                    }
                });
            }
        }

        /** Drops any dependency whose slug matches a mod id already found in the mods
         *  folder (see promptForDependencies), then shows the dialog with what's left —
         *  or skips it entirely and downloads directly if nothing's left to ask about. */
        private void finishDependencyPrompt(Context context, String url, String fileName,
                                             String[] depIds, String[] depTypes, String[] labels,
                                             String[] slugs, boolean[] checkedDefaults,
                                             java.util.Set<String> installedModIds, String oldFilePath) {
            List<String> keptIds = new ArrayList<>();
            List<String> keptTypes = new ArrayList<>();
            List<String> keptLabels = new ArrayList<>();
            List<Boolean> keptChecked = new ArrayList<>();
            for (int i = 0; i < depIds.length; i++) {
                String slug = slugs[i];
                if (slug != null && installedModIds.contains(slug.toLowerCase(java.util.Locale.ROOT))) continue;
                keptIds.add(depIds[i]);
                keptTypes.add((depTypes != null && i < depTypes.length) ? depTypes[i] : "required");
                keptLabels.add(labels[i]);
                keptChecked.add(checkedDefaults[i]);
            }

            if (keptIds.isEmpty()) {
                downloadMod(context, url, fileName, new String[0], new String[0], oldFilePath);
                return;
            }

            boolean[] checkedArr = new boolean[keptChecked.size()];
            for (int i = 0; i < checkedArr.length; i++) checkedArr[i] = keptChecked.get(i);

            showDepsDialog(context, url, fileName,
                    keptIds.toArray(new String[0]), keptTypes.toArray(new String[0]),
                    keptLabels.toArray(new String[0]), checkedArr, oldFilePath);
        }

        private void showDepsDialog(Context context, String url, String fileName,
                                    String[] depIds, String[] depTypes,
                                    String[] labels, boolean[] checkedDefaults, String oldFilePath) {
            // context here is getApplicationContext() from ModItemAdapter — no window token.
            // Use the stored Activity reference instead.
            Context dialogCtx = mActivityContext != null ? mActivityContext : context;
            boolean[] selected = checkedDefaults.clone();

            new MaterialAlertDialogBuilder(dialogCtx)
                    .setTitle(R.string.mod_deps_title)
                    .setMultiChoiceItems(labels, selected,
                            (dialog, which, isChecked) -> selected[which] = isChecked)
                    .setPositiveButton(R.string.mod_deps_install_selected, (d, w) -> {
                        List<String> selectedIds = new ArrayList<>();
                        for (int i = 0; i < depIds.length; i++) {
                            if (selected[i]) selectedIds.add(depIds[i]);
                        }
                        downloadMod(context, url, fileName,
                                selectedIds.toArray(new String[0]), depTypes, oldFilePath);
                    })
                    .setNeutralButton(R.string.mod_deps_install_without,
                            (d, w) -> downloadMod(context, url, fileName, new String[0], new String[0], oldFilePath))
                    .setNegativeButton(android.R.string.cancel, null)
                    .show();
        }

        private void downloadMod(Context context, String url, String fileName,
                                  String[] depIds, String[] depTypes, @Nullable String oldFilePath) {
            File modsDir = getModsDir();
            if (modsDir == null) return;
            if (!modsDir.exists()) modsDir.mkdirs();

            final File targetFile = new File(modsDir, fileName);
            final String installedInto = mFilters.contentType == ContentType.DATAPACK ? currentWorld() : null;

            ProgressLayout.setProgress(ProgressLayout.INSTALL_MODPACK, 0, R.string.global_waiting);
            MojoApplication.sExecutorService.execute(() -> {
                try {
                    // Download main mod
                    DownloadUtils.downloadFile(url, targetFile);

                    // This is an update/downgrade of an already-installed mod under a
                    // different file name — remove the old jar now that the new one
                    // downloaded successfully, so both versions don't end up sitting
                    // in the mods folder side-by-side.
                    if (oldFilePath != null) {
                        File oldFile = new File(oldFilePath);
                        if (oldFile.exists() && !oldFile.getAbsolutePath().equals(targetFile.getAbsolutePath())) {
                            oldFile.delete();
                        }
                    }

                    // Download selected dependencies
                    for (String depId : depIds) {
                        if (depId == null || depId.isEmpty()) continue;
                        downloadDependency(depId);
                    }

                    ProgressLayout.clearProgress(ProgressLayout.INSTALL_MODPACK);
                    Tools.runOnUiThread(() ->
                            Toast.makeText(context,
                                    installedInto != null
                                            ? context.getString(R.string.datapack_install_success, fileName, installedInto)
                                            : context.getString(R.string.mod_install_success, fileName),
                                    Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    ProgressLayout.clearProgress(ProgressLayout.INSTALL_MODPACK);
                    Tools.showErrorRemote(context, R.string.modpack_install_download_failed, e);
                } finally {
                    mPickedWorld = null;
                }
            });
        }

        /**
         * Downloads a single dependency into whichever folder actually matches its own
         * content type — not necessarily the same folder as whatever's depending on it.
         * A shader pack's dependency is very often a mod (Iris); some resource packs
         * depend on a mod too (Continuity, for CTM support). Downloading those into the
         * shader pack / resource pack folder instead of the mods folder would mean the
         * game's mod loader never even sees them — and forcing the parent's file
         * extension onto them would leave a mangled file like "iris.jar.zip" behind.
         */
        private void downloadDependency(String projectId) {
            try {
                String[] details = fetchProjectDetails(projectId);
                ContentType depType = (details != null && details.length > 2 && details[2] != null)
                        ? ContentType.fromModrinthType(details[2]) : mFilters.contentType;

                String filterVer = (mFilters.mcVersion != null && !mFilters.mcVersion.isEmpty())
                        ? mFilters.mcVersion : "";
                // Loader filtering only makes sense when the dependency is itself a mod —
                // resource pack / shader pack versions aren't tagged with fabric/forge/etc,
                // so passing a loader filter through for those would zero out every result.
                String filterLoader = (depType == ContentType.MOD
                        && mFilters.modLoader != null && !mFilters.modLoader.isEmpty())
                        ? mFilters.modLoader : null;

                ModItem depItem = new ModItem(
                        git.artdeell.mojo.modding.modpacks.models.Constants.SOURCE_MODRINTH,
                        false, projectId, projectId, "", "");
                ModDetail depDetail = mModrinthApi.getModDetails(depItem, filterVer.isEmpty() ? null : filterVer, filterLoader);
                if (depDetail == null || depDetail.versionUrls == null || depDetail.versionUrls.length == 0) return;

                String depUrl = depDetail.versionUrls[0];
                String depName = depUrl.substring(depUrl.lastIndexOf('/') + 1);
                if (depName.contains("?")) depName = depName.substring(0, depName.indexOf('?'));
                if (!depName.endsWith(depType.fileExtension)) depName += depType.fileExtension;

                File targetDir = getContentDir(depType);
                if (targetDir == null) return;
                if (!targetDir.exists()) targetDir.mkdirs();

                DownloadUtils.downloadFile(depUrl, new File(targetDir, depName));
            } catch (Exception e) {
                Log.w(TAG, "Failed to download dependency " + projectId + ": " + e.getMessage());
            }
        }

        /**
         * Hashes every jar currently in the mods folder and bulk-resolves them against
         * Modrinth's version_files endpoint to find which Modrinth project each one
         * belongs to — used to filter "install dependencies" prompts down to ones that
         * aren't already installed under some other version/file name.
         */
        /**
         * Every content file (mod/resourcepack/shaderpack) currently installed for this
         * instance, across all three folders — not just whichever ContentType is being
         * browsed right now. Dependencies aren't necessarily the same content type as
         * the thing depending on them: shader packs commonly depend on a mod (Iris),
         * and resource packs sometimes depend on a mod too (e.g. Continuity for CTM
         * support). Scoping the "already installed" check to only the current content
         * type's folder meant those cross-type dependencies could never be recognized
         * as installed, even when they plainly were — this fixes that by checking
         * everywhere a piece of content could live for this instance.
         */
        private File[] getAllInstalledContentFiles() {
            List<File> all = new ArrayList<>();
            for (ContentType type : ContentType.values()) {
                if (!type.isGameFolderFiles()) continue;
                File dir = getContentDir(type);
                if (dir == null) continue;
                File[] files = dir.listFiles(f -> f.isFile() &&
                        (f.getName().endsWith(type.fileExtension) ||
                                f.getName().endsWith(type.fileExtension + ".disabled")));
                if (files != null) all.addAll(java.util.Arrays.asList(files));
            }
            return all.toArray(new File[0]);
        }

        private java.util.Set<String> getInstalledModrinthProjectIds() {
            java.util.Set<String> projectIds = new java.util.HashSet<>();
            File[] files = getAllInstalledContentFiles();
            if (files.length == 0) return projectIds;

            List<String> hashes = new ArrayList<>();
            for (File f : files) {
                String hash = sha1Hex(f);
                if (hash != null) hashes.add(hash);
            }
            if (hashes.isEmpty()) return projectIds;

            try {
                com.google.gson.JsonObject body = new com.google.gson.JsonObject();
                com.google.gson.JsonArray hashArray = new com.google.gson.JsonArray();
                for (String hash : hashes) hashArray.add(hash);
                body.add("hashes", hashArray);
                body.addProperty("algorithm", "sha1");

                java.util.Map<String, String> headers = new java.util.HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Accept", "application/json");

                String responseRaw = git.artdeell.mojo.modding.modpacks.api.ApiHandler.postRaw(
                        headers, "https://api.modrinth.com/v2/version_files", body.toString());
                if (responseRaw == null) return projectIds;

                com.google.gson.JsonObject response = com.google.gson.JsonParser.parseString(responseRaw).getAsJsonObject();
                for (java.util.Map.Entry<String, com.google.gson.JsonElement> entry : response.entrySet()) {
                    if (!entry.getValue().isJsonObject()) continue;
                    com.google.gson.JsonObject version = entry.getValue().getAsJsonObject();
                    if (version.has("project_id") && !version.get("project_id").isJsonNull()) {
                        projectIds.add(version.get("project_id").getAsString());
                    }
                }
            } catch (Exception e) {
                Log.w(TAG, "Failed to bulk-resolve installed mod hashes: " + e.getMessage());
            }
            return projectIds;
        }

        /** Fetches a Modrinth project's title, slug, and project_type in one call.
         *  Returns {title, slug, projectType} (any element may be null), or null
         *  entirely if the lookup failed. */
        private String[] fetchProjectDetails(String projectId) {
            try {
                git.artdeell.mojo.modding.modpacks.api.ApiHandler handler =
                        new git.artdeell.mojo.modding.modpacks.api.ApiHandler("https://api.modrinth.com/v2");
                com.google.gson.JsonObject obj = handler.get("project/" + projectId,
                        com.google.gson.JsonObject.class);
                if (obj == null) return null;
                String title = (obj.has("title") && !obj.get("title").isJsonNull())
                        ? obj.get("title").getAsString() : null;
                String slug = (obj.has("slug") && !obj.get("slug").isJsonNull())
                        ? obj.get("slug").getAsString() : null;
                String projectType = (obj.has("project_type") && !obj.get("project_type").isJsonNull())
                        ? obj.get("project_type").getAsString() : null;
                return new String[]{title, slug, projectType};
            } catch (Exception ignored) {}
            return null;
        }

        /**
         * Reads the mod id (not the display name) embedded in every jar currently in the
         * mods folder — straight from fabric.mod.json / quilt.mod.json / mods.toml /
         * mcmod.info. Unlike {@link #getInstalledModrinthProjectIds()} this needs no
         * network call and doesn't care where the jar originally came from, so it also
         * catches dependencies that were installed via CurseForge or dropped in manually
         * — cases the Modrinth-hash lookup can never see since those jars simply don't
         * have a Modrinth file hash to match against.
         */
        private java.util.Set<String> getInstalledModIds() {
            java.util.Set<String> ids = new java.util.HashSet<>();
            for (File f : getAllInstalledContentFiles()) {
                String id = extractModId(f);
                if (id != null && !id.isEmpty()) ids.add(id.toLowerCase(java.util.Locale.ROOT));
            }
            return ids;
        }

        private static String extractModId(File jarFile) {
            try (ZipFile zip = new ZipFile(jarFile)) {
                String content = readZipEntry(zip, "fabric.mod.json");
                if (content != null) {
                    try {
                        com.google.gson.JsonObject obj = com.google.gson.JsonParser.parseString(content).getAsJsonObject();
                        if (obj.has("id") && !obj.get("id").isJsonNull()) {
                            String id = obj.get("id").getAsString().trim();
                            if (!id.isEmpty()) return id;
                        }
                    } catch (Exception ignored) {}
                }
                content = readZipEntry(zip, "quilt.mod.json");
                if (content != null) {
                    try {
                        com.google.gson.JsonObject root = com.google.gson.JsonParser.parseString(content).getAsJsonObject();
                        com.google.gson.JsonObject ql = root.has("quilt_loader") ? root.getAsJsonObject("quilt_loader") : null;
                        if (ql != null && ql.has("id") && !ql.get("id").isJsonNull()) {
                            String id = ql.get("id").getAsString().trim();
                            if (!id.isEmpty()) return id;
                        }
                    } catch (Exception ignored) {}
                }
                for (String toml : new String[]{"META-INF/neoforge.mods.toml", "META-INF/mods.toml"}) {
                    content = readZipEntry(zip, toml);
                    if (content != null) {
                        String modId = tomlStringField(content, "modId");
                        if (modId != null && !modId.isEmpty()) return modId.trim();
                    }
                }
                content = readZipEntry(zip, "mcmod.info");
                if (content != null) {
                    try {
                        com.google.gson.JsonArray arr = com.google.gson.JsonParser.parseString(content).getAsJsonArray();
                        if (arr.size() > 0 && arr.get(0).isJsonObject()) {
                            com.google.gson.JsonObject mod = arr.get(0).getAsJsonObject();
                            if (mod.has("modid") && !mod.get("modid").isJsonNull()) {
                                String id = mod.get("modid").getAsString().trim();
                                if (!id.isEmpty()) return id;
                            }
                        }
                    } catch (Exception ignored) {}
                }
            } catch (Exception e) {
                Log.w(TAG, "Failed to read mod id from JAR: " + jarFile.getName() + " - " + e.getMessage());
            }
            return null;
        }

        private static String readZipEntry(ZipFile zip, String entryPath) {
            ZipEntry entry = zip.getEntry(entryPath);
            if (entry == null) return null;
            try (InputStream is = zip.getInputStream(entry)) {
                return Tools.read(is);
            } catch (Exception e) {
                return null;
            }
        }

        /** Minimal `field = "value"` line lookup — enough for the modId line in mods.toml. */
        private static String tomlStringField(String content, String field) {
            Matcher m = Pattern.compile(field + "\\s*=\\s*\"([^\"]*)\"").matcher(content);
            return m.find() ? m.group(1) : null;
        }

        /** World a datapack is installed into: the one the browser was opened for, else the picked one */
        @Nullable
        private String currentWorld() {
            return mTargetWorld != null ? mTargetWorld : mPickedWorld;
        }

        /**
         * Downloads a world zip and extracts it into the saves folder. CurseForge world zips hold
         * the world folder, some have the level.dat at the top level, both are handled.
         */
        private void installWorld(Context context, String url, String title) {
            String rawName = url.substring(url.lastIndexOf('/') + 1);
            if (rawName.contains("?")) rawName = rawName.substring(0, rawName.indexOf('?'));
            if (rawName.toLowerCase(java.util.Locale.ROOT).endsWith(".zip")) {
                rawName = rawName.substring(0, rawName.length() - 4);
            }
            final String fallbackName = rawName.isEmpty() ? title : rawName;
            final File savesDir = WorldUtils.getSavesDirectory();
            final File tempZip = new File(Tools.DIR_CACHE, "world_download_" + System.nanoTime() + ".zip");

            ProgressLayout.setProgress(ProgressLayout.INSTALL_MODPACK, 0, R.string.global_waiting);
            MojoApplication.sExecutorService.execute(() -> {
                try {
                    DownloadUtils.downloadFileMonitored(url, tempZip, null, (current, max) ->
                            ProgressLayout.setProgress(ProgressLayout.INSTALL_MODPACK,
                                    max > 0 ? (int) (current * 100L / max) : 0,
                                    R.string.world_downloading, title));
                    ProgressLayout.setProgress(ProgressLayout.INSTALL_MODPACK, 100, R.string.world_extracting, title);
                    File world = WorldUtils.extractWorldZip(tempZip, savesDir, fallbackName);
                    ProgressLayout.clearProgress(ProgressLayout.INSTALL_MODPACK);
                    Tools.runOnUiThread(() ->
                            Toast.makeText(context,
                                    context.getString(R.string.world_install_success, world.getName()),
                                    Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    ProgressLayout.clearProgress(ProgressLayout.INSTALL_MODPACK);
                    Tools.showErrorRemote(context, R.string.modpack_install_download_failed, e);
                } finally {
                    tempZip.delete();
                }
            });
        }

        @Nullable
        private File getModsDir() {
            return getContentDir(mFilters.contentType);
        }

        /** @return the folder the content type is installed into, null for datapacks without a world */
        @Nullable
        private File getContentDir(ContentType type) {
            if (type == ContentType.WORLD) return WorldUtils.getSavesDirectory();
            if (type == ContentType.DATAPACK) {
                String world = currentWorld();
                return world != null ? WorldUtils.getDatapacksDirectory(world) : null;
            }
            return new File(WorldUtils.getGameDirectory(), type.folderName);
        }
    }
}
