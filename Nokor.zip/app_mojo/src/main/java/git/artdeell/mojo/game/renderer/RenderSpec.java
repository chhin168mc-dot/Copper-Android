package git.artdeell.mojo.game.renderer;

import android.content.Context;

import java.util.Map;

/**
 * Interface representing a renderer specification
 */
public interface RenderSpec {
    /**
     * Check if the current device is able to use this renderer
     *
     * @param context application context
     * @return whether the renderer is compatible
     */
    boolean compatibleDevice(Context context);

    /**
     * Renderer name (or tag?)
     *
     * @return name
     */
    String name();

    /**
     * Renderer resource display name
     *
     * @return resource id
     */
    int displayName();

    /**
     * Display name shown in the renderer list. Plugins override this to provide a runtime name
     * instead of a resource id.
     *
     * @param context application context
     * @return display name
     */
    default String getDisplayName(Context context) {
        return context.getString(displayName());
    }

    /**
     * Renderer tag
     *
     * @return tag
     */
    String tag();

    /**
     * Renderer EGL library
     *
     * @return library name or path
     */
    String library();

    /**
     * Optional library path if the renderer is linked with libs outside of the launcher native directory
     * @return String (or null if the extra search path is not needed)
     */
    default String librarySearchPath() {
        return null;
    }

    /**
     * Prepare renderer usage in the game. Sets up environment and some other things
     *
     * @param context application context
     * @param envMap  environment map
     */
    void setupEnvironment(Context context, Map<String, String> envMap);

    /**
     * Setup this renderer in MojoExec. Prefer using {@link GameRenderer#maybeSetupRenderer()}
     *
     * @return whether the setup was successful
     */
    boolean setupRenderer();
}
