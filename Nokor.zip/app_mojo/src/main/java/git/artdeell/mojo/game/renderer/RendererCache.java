package git.artdeell.mojo.game.renderer;

import static git.artdeell.mojo.game.renderer.def.Renderers.FREEDRENO_RENDERER;
import static git.artdeell.mojo.game.renderer.def.Renderers.GL4ES_RENDERER;
import static git.artdeell.mojo.game.renderer.def.Renderers.LEGACYZINK_RENDERER;
import static git.artdeell.mojo.game.renderer.def.Renderers.LTW_RENDERER;
import static git.artdeell.mojo.game.renderer.def.Renderers.MESA_RENDERER;
import static git.artdeell.mojo.game.renderer.def.Renderers.MESA_RENDERER_EXT;
import static git.artdeell.mojo.game.renderer.def.Renderers.MOBILEGLUES_RENDERER;
import static git.artdeell.mojo.game.renderer.def.Renderers.SFPEW_RENDERER;
import static git.artdeell.mojo.game.renderer.def.Renderers.ZINK_RENDERER;

import android.content.Context;

import git.artdeell.mojo.game.renderer.impl.PluginRenderSpec;
import git.artdeell.mojo.utils.plugins.PluginManager;
import git.artdeell.mojo.utils.plugins.RendererPlugin;

import java.util.ArrayList;
import java.util.List;

/**
 * Compatible renderers cache. Used for the UI renderer list
 */
public class RendererCache {
    private static RendererCache sCompatibleRenderers;

    public final List<String> rendererIds;
    public final String[] rendererDisplayNames;

    public RendererCache(List<String> rendererIds, String[] rendererDisplayNames) {
        this.rendererIds = rendererIds;
        this.rendererDisplayNames = rendererDisplayNames;
    }

    /**
     * Return a list of renderers compatible with the current device
     * Don't forget to clean the cache when the list isn't needed anymore
     *
     * @param context application context
     * @return RenderersList containing all compatible renderers
     */
    public static RendererCache getCompatibleRenderers(Context context) {
        if (sCompatibleRenderers != null) return sCompatibleRenderers;
        // This is the list that controls em all!
        String[] renderers = {
                GL4ES_RENDERER, ZINK_RENDERER, LTW_RENDERER, MOBILEGLUES_RENDERER, SFPEW_RENDERER, FREEDRENO_RENDERER, MESA_RENDERER, MESA_RENDERER_EXT, LEGACYZINK_RENDERER
        };
        ArrayList<String> rendererIds = new ArrayList<>(renderers.length);
        ArrayList<String> rendererNames = new ArrayList<>(rendererIds);
        for (String renderer : renderers) {
            RenderSpec r = GameRenderer.getKnownRenderer(renderer);
            assert r != null;
            if (!r.compatibleDevice(context)) continue;
            rendererIds.add(renderer);
            rendererNames.add(r.getDisplayName(context));
        }
        for (RendererPlugin plugin : PluginManager.getRendererPlugins(context)) {
            RenderSpec r = new PluginRenderSpec(plugin.packageName);
            if (!r.compatibleDevice(context)) continue;
            rendererIds.add(r.tag());
            rendererNames.add(r.getDisplayName(context));
        }
        rendererIds.trimToSize();
        rendererNames.trimToSize();
        return (sCompatibleRenderers = new RendererCache(rendererIds, rendererNames.toArray(new String[0])));
    }

    /**
     * Destroy compatible renderers cache
     */
    public static void releaseRendererCache() {
        sCompatibleRenderers.rendererIds.clear();
        sCompatibleRenderers = null;
    }
}
