package git.artdeell.mojo.prefs.screens;


import git.artdeell.mojo.prefs.BackButtonPreference;
import git.artdeell.mojo.fragments.SettingsHostFragment;
import androidx.preference.PreferenceScreen;
import android.content.res.Configuration;
import android.content.pm.ActivityInfo;
import git.artdeell.mojo.utils.AnimationManager;
import git.artdeell.mojo.utils.ThemeColors;
import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.widget.Toast;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;

import git.artdeell.mojo.LauncherActivity;
import git.artdeell.mojo.R;
import git.artdeell.mojo.prefs.LauncherPreferences;
import git.artdeell.mojo.utils.ThemeManager;

/**
 * Preference for the main screen, any sub-screen should inherit this class for consistent behavior,
 * overriding only onCreatePreferences
 */
public class LauncherPreferenceFragment extends PreferenceFragmentCompat implements SharedPreferences.OnSharedPreferenceChangeListener {
    protected Runnable mVisibilityUpdater = () -> {};
    private boolean mRecreatePending;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        // The list of categories in the left pane of the two-pane settings draws on the host background
        if(!isSettingsListPane()) view.setBackgroundColor(ThemeColors.surface(view.getContext()));
        super.onViewCreated(view, savedInstanceState);
        AnimationManager.applyListAnimation(getListView());
    }

    @Override
    public void onCreatePreferences(Bundle b, String str) {
        mVisibilityUpdater = this::updateVisibility;
        addPreferencesFromResource(R.xml.pref_main);
        // The right pane of the two-pane settings has its own back button
        if(isSettingsListPane()) removeBackButton();
        setupNotificationRequestPreference();
        setupAnnouncementAdminPreference();
    }

    /**
     * Opens the announcement admin page of the backend in the browser. The page starts the Google login
     * by itself (only the allowlisted email gets in). The external browser is used on purpose: Google
     * blocks the login inside an embedded WebView.
     */
    private void setupAnnouncementAdminPreference() {
        Preference preference = findPreference("announcement_admin");
        if(preference == null) return;
        preference.setOnPreferenceClickListener(p -> {
            String base = getString(R.string.update_api_url).trim().replaceAll("/+$", "");
            if(!base.startsWith("https://")) {
                Toast.makeText(requireContext(), "Server URL is not set", Toast.LENGTH_LONG).show();
                return true;
            }
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(base + "/api/admin/announcement-ui")));
            } catch (ActivityNotFoundException e) {
                Toast.makeText(requireContext(), "No browser found", Toast.LENGTH_LONG).show();
            }
            return true;
        });
    }

    /** @return whether this is the list of categories inside the left pane of the two-pane settings */
    private boolean isSettingsListPane() {
        // Only the category list itself, not the categories that extend this fragment
        return getClass() == LauncherPreferenceFragment.class
                && getParentFragment() instanceof SettingsHostFragment
                && getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
    }

    private void removeBackButton() {
        PreferenceScreen screen = getPreferenceScreen();
        for(int i = 0; i < screen.getPreferenceCount(); i++) {
            Preference preference = screen.getPreference(i);
            if(preference instanceof BackButtonPreference) {
                screen.removePreference(preference);
                return;
            }
        }
    }

    private void updateVisibility(){
        requirePreference("notification_permission_request").setVisible(!getLauncherActivity().checkForPermission(33, Manifest.permission.POST_NOTIFICATIONS));
    }

    private void setupNotificationRequestPreference() {
        Preference mRequestNotificationPermissionPreference = requirePreference("notification_permission_request");
        Activity activity = getActivity();
        if(activity instanceof LauncherActivity) {
            mRequestNotificationPermissionPreference.setOnPreferenceClickListener(preference -> {
                ((LauncherActivity) activity).askForPermission(33, Manifest.permission.POST_NOTIFICATIONS);
                return true;
            });
        }else{
            mRequestNotificationPermissionPreference.setVisible(false);
        }
        updateVisibility();
    }

    @Override
    public void onResume() {
        super.onResume();
        SharedPreferences sharedPreferences = getPreferenceManager().getSharedPreferences();
        if(sharedPreferences != null) sharedPreferences.registerOnSharedPreferenceChangeListener(this);
        mVisibilityUpdater.run();
    }

    @Override
    public void onPause() {
        SharedPreferences sharedPreferences = getPreferenceManager().getSharedPreferences();
        if(sharedPreferences != null) sharedPreferences.unregisterOnSharedPreferenceChangeListener(this);
        super.onPause();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences p, String s) {
        LauncherPreferences.loadPreferences(getContext());
        if(ThemeManager.PREF_THEME_MODE.equals(s)) {
            ThemeManager.applyThemeMode(p.getString(s, ThemeManager.DEFAULT_THEME_MODE));
        }else if(ThemeManager.PREF_COLOR_SOURCE.equals(s) || ThemeManager.PREF_CUSTOM_COLOR.equals(s)
                || AnimationManager.PREF_TYPES.equals(s)) {
            scheduleRecreate();
        }
    }

    /** Recreates the activity to apply a new theme, only once even if multiple keys changed together */
    private void scheduleRecreate() {
        Activity activity = getActivity();
        if(activity == null || mRecreatePending) return;
        mRecreatePending = true;
        activity.getWindow().getDecorView().post(activity::recreate);
    }

    protected Preference requirePreference(CharSequence key) {
        Preference preference = findPreference(key);
        if(preference != null) return preference;
        throw new IllegalStateException("Preference "+key+" is null");
    }
    @SuppressWarnings("unchecked")
    protected <T extends Preference> T requirePreference(CharSequence key, Class<T> preferenceClass) {
        Preference preference = requirePreference(key);
        if(preferenceClass.isInstance(preference)) return (T)preference;
        throw new IllegalStateException("Preference "+key+" is not an instance of "+preferenceClass.getSimpleName());
    }
    protected LauncherActivity getLauncherActivity(){
        return ((LauncherActivity) getActivity());
    }
}
