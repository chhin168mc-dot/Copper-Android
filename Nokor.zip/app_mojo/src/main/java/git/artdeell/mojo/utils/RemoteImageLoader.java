package git.artdeell.mojo.utils;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.net.Uri;
import android.util.Base64;
import android.util.LruCache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.caverock.androidsvg.SVG;
import com.caverock.androidsvg.SVGParseException;

import git.artdeell.mojo.MojoApplication;
import git.artdeell.mojo.Tools;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

/**
 * Small downloader for the pictures of the content detail screen (logo, gallery and the pictures
 * of descriptions). Raster pictures are downsampled while decoding, SVG pictures (badges, logos)
 * are drawn at their natural size for the screen density. Addresses can be {@code data:} URIs.
 * Pictures are kept in a memory cache, the callbacks always run on the UI thread. The mod list keeps using its own disk backed icon cache.
 */
public final class RemoteImageLoader {
    private static final int MAX_DOWNLOAD_BYTES = 12 * 1024 * 1024;
    /** Originals of gallery pictures can be big, they are only downloaded when one is opened */
    private static final int MAX_FULL_DOWNLOAD_BYTES = 64 * 1024 * 1024;
    /** Longest side a full quality picture is decoded at, the usual GPU texture limit */
    public static final int FULL_QUALITY_DIMENSION = 4096;
    private static final int CONNECT_TIMEOUT_MS = 10_000;
    private static final int READ_TIMEOUT_MS = 20_000;
    private static final String USER_AGENT =
            "CopperLauncher/Copper-Android (https://github.com/CopperLauncher/Copper-Android)";

    private static final LruCache<String, Bitmap> sCache =
            new LruCache<String, Bitmap>((int) (Runtime.getRuntime().maxMemory() / 1024 / 10)) {
                @Override
                protected int sizeOf(String key, Bitmap value) {
                    return value.getByteCount() / 1024;
                }
            };

    private RemoteImageLoader() {}

    public interface Callback {
        /** @param bitmap the picture, null if it could not be loaded */
        void onImage(@Nullable Bitmap bitmap);
    }

    /**
     * @param maxDimension the longest side the picture is going to be shown at, in pixels
     * @return a handle to cancel the load with, cancelled loads never call back
     */
    @NonNull
    public static Future<?> load(@NonNull String url, int maxDimension, @NonNull Callback callback) {
        return load(url, maxDimension, MAX_DOWNLOAD_BYTES, callback);
    }

    /** Loads the picture at the best quality that can be shown, not downscaled to the screen size */
    @NonNull
    public static Future<?> loadFullQuality(@NonNull String url, @NonNull Callback callback) {
        return load(url, FULL_QUALITY_DIMENSION, MAX_FULL_DOWNLOAD_BYTES, callback);
    }

    @NonNull
    private static Future<?> load(@NonNull String url, int maxDimension, int maxBytes, @NonNull Callback callback) {
        String cacheKey = url + "@" + maxDimension;
        Bitmap cached = sCache.get(cacheKey);
        if (cached != null) {
            Tools.runOnUiThread(() -> callback.onImage(cached));
            FutureTask<Object> done = new FutureTask<>(() -> null);
            done.run();
            return done;
        }
        return MojoApplication.sExecutorService.submit(() -> {
            Bitmap bitmap = download(url, maxDimension, maxBytes);
            if (bitmap != null) sCache.put(cacheKey, bitmap);
            if (Thread.currentThread().isInterrupted()) return;
            Tools.runOnUiThread(() -> callback.onImage(bitmap));
        });
    }

    @Nullable
    private static Bitmap download(String url, int maxDimension, int maxBytes) {
        byte[] data = url.startsWith("data:") ? decodeDataUri(url) : fetch(url, maxBytes);
        if (data == null || data.length == 0 || Thread.currentThread().isInterrupted()) return null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return decodeSvg(data, maxDimension);

            int sample = 1;
            int longest = Math.max(bounds.outWidth, bounds.outHeight);
            while (longest / (sample * 2) >= maxDimension) sample *= 2;

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            return BitmapFactory.decodeByteArray(data, 0, data.length, options);
        } catch (RuntimeException | OutOfMemoryError e) {
            return null;
        }
    }

    @Nullable
    private static byte[] fetch(String url, int maxBytes) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setRequestProperty("User-Agent", USER_AGENT);
            try (InputStream in = connection.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[16 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                    if (out.size() > maxBytes) return null;
                    if (Thread.currentThread().isInterrupted()) return null;
                }
                return out.toByteArray();
            }
        } catch (IOException | RuntimeException e) {
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    @Nullable
    private static byte[] decodeDataUri(String uri) {
        int comma = uri.indexOf(',');
        if (comma < 0) return null;
        try {
            String payload = uri.substring(comma + 1);
            if (uri.substring(0, comma).toLowerCase().contains(";base64")) {
                return Base64.decode(payload, Base64.DEFAULT);
            }
            return Uri.decode(payload).getBytes(StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /** SVG has no pixel size, it is drawn at its document size times the screen density */
    @Nullable
    private static Bitmap decodeSvg(byte[] data, int maxDimension) {
        try {
            SVG svg = SVG.getFromInputStream(new ByteArrayInputStream(data));
            float width = svg.getDocumentWidth();
            float height = svg.getDocumentHeight();
            RectF box = svg.getDocumentViewBox();
            if (width <= 0 || height <= 0) {
                if (box != null && box.width() > 0 && box.height() > 0) {
                    width = box.width();
                    height = box.height();
                } else {
                    width = 300;
                    height = 150;
                }
            }
            if (box == null) svg.setDocumentViewBox(0, 0, width, height);

            float scale = Resources.getSystem().getDisplayMetrics().density;
            float longest = Math.max(width, height) * scale;
            if (longest > maxDimension) scale *= maxDimension / longest;
            int bitmapWidth = Math.max(1, Math.round(width * scale));
            int bitmapHeight = Math.max(1, Math.round(height * scale));

            Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888);
            svg.renderToCanvas(new Canvas(bitmap), new RectF(0, 0, bitmapWidth, bitmapHeight));
            return bitmap;
        } catch (SVGParseException | RuntimeException | OutOfMemoryError e) {
            return null;
        }
    }
}
