package android.util;
public class Log { public static int i(String t,String m){return 0;} public static int w(String t,String m){System.out.println("  [W] "+m);return 0;} public static int w(String t,String m,Throwable e){return 0;} public static int e(String t,String m){return 0;} }
